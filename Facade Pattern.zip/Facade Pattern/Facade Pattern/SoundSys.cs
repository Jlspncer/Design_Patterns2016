﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade_Pattern
{
    public class SoundSys      // A subsystem class to control the sound system
    {
        private bool isOn = false;

        public bool soundOn() // Determines if the sound system is on
        {
            return isOn;
        }

        public void sysOn()
        {
            isOn = true;
        }

        public void sysOff()
        {
            isOn = false;
        }
    }
}
