﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Facade_Pattern
{
    public partial class frmRemote : Form
    {
        Univ_Remote Remote;
        public frmRemote()
        {
            InitializeComponent();
            Remote = new Univ_Remote();
        }

        private void compActive()       // Method to determine if components are active
        {
            if (Remote.TV.tvActive())
                txt_TV.Text = "Active";
            else
                txt_TV.Text = "Off";

            if (Remote.Xbox.xboxOn())
                txt_BR.Text = "Active";
            else
                txt_BR.Text = "Off";

            if (Remote.Record.turnTblOn())
                txt_Record.Text = "Active";
            else
                txt_Record.Text = "Off";

            if (Remote.CD.playerOn())
                txt_CD.Text = "Active";
            else
                txt_CD.Text = "Off";

            if (Remote.Sound.soundOn())
                txt_Sound.Text = "Active";
            else
                txt_Sound.Text = "Off";
        }

        private void btn_Off_Click(object sender, EventArgs e)
        {
            Remote.allOff();
            compActive();
        }

        private void btn_TV_Click(object sender, EventArgs e)
        {
            Remote.cableTV();
            compActive();
        }

        private void btn_BR_Click(object sender, EventArgs e)
        {
            Remote.bluRay();
            compActive();
        }

        private void btn_Record_Click(object sender, EventArgs e)
        {
            Remote.recPlay();
            compActive();
        }

        private void btn_CD_Click(object sender, EventArgs e)
        {
            Remote.cdPlay();
            compActive();
        }
    }
}
