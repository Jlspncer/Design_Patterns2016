﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade_Pattern
{
    public class XBR       // A subsystem class that controls the Xbox/BR player
    {
        private bool isOn = false;

        public bool xboxOn()     // Determines if the Xbox is on
        {
            return isOn;
        }

        public void brON()
        {
            isOn = true;
        }

        public void brOFF()
        {
            isOn = false;
        }
    }
}
