﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade_Pattern
{
    public class Univ_Remote        // The Facade Class
    {
        public TV TV = new TV();
        public XBR Xbox = new XBR();
        public Record Record = new Record();
        public CD CD = new CD();
        public SoundSys Sound = new SoundSys();

        public void cableTV()   // Activates the TV only
        {
            TV.tvON();
            Xbox.brOFF();
            Record.recOFF();
            CD.cdOFF();
            Sound.sysOff();
        }

        public void bluRay()    // Activates the TV and the Xbox
        {
            TV.tvON();
            Xbox.brON();
            Record.recOFF();
            CD.cdOFF();
            Sound.sysOff();
        }

        public void recPlay()      // Activates the Turntable and the sound system
        {
            TV.tvOFF();
            Xbox.brOFF();
            Record.recON();
            CD.cdOFF();
            Sound.sysOn();
        }

        public void cdPlay()    // Activates the CD player and the sound system
        {
            TV.tvOFF();
            Xbox.brOFF();
            Record.recOFF();
            CD.cdON();
            Sound.sysOn();
        }

        public void allOff()    // Deactivates all components
        {
            TV.tvOFF();
            Xbox.brOFF();
            Record.recOFF();
            CD.cdOFF();
            Sound.sysOff();
        }
    }
}
