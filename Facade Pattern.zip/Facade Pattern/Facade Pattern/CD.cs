﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade_Pattern
{
    public class CD        // A subsystem class to control the CD player
    {
        private bool isOn = false;

        public bool playerOn()     // Determines if the player is on
        {
            return isOn;
        }

        public void cdON()
        {
            isOn = true;
        }

        public void cdOFF()
        {
            isOn = false;
        }
    }
}
