﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade_Pattern
{
    public class TV   // A subsystem class to control TV
    {
        private bool isOn = false; 
     
        public bool tvActive()      // Determines TV Active or not
        {
            return isOn;
        }

        public void tvON()  // Turn On Method
        {
            isOn = true;
        }

        public void tvOFF()     // Turn Off Method
        {
            isOn = false;
        }
    }
}
