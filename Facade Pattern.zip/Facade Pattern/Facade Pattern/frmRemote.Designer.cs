﻿namespace Facade_Pattern
{
    partial class frmRemote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_TV = new System.Windows.Forms.Button();
            this.btn_BR = new System.Windows.Forms.Button();
            this.btn_Record = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_CD = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_TV = new System.Windows.Forms.TextBox();
            this.txt_BR = new System.Windows.Forms.TextBox();
            this.txt_Record = new System.Windows.Forms.TextBox();
            this.txt_CD = new System.Windows.Forms.TextBox();
            this.txt_Sound = new System.Windows.Forms.TextBox();
            this.btn_Off = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(225, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Entertainment Remote";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(53, 267);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "4K Ultra HDTV ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(61, 297);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Xbox/Blu-Ray";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(60, 332);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Record Player";
            // 
            // btn_TV
            // 
            this.btn_TV.Location = new System.Drawing.Point(25, 106);
            this.btn_TV.Name = "btn_TV";
            this.btn_TV.Size = new System.Drawing.Size(181, 41);
            this.btn_TV.TabIndex = 4;
            this.btn_TV.Text = "Cable TV";
            this.btn_TV.UseVisualStyleBackColor = true;
            this.btn_TV.Click += new System.EventHandler(this.btn_TV_Click);
            // 
            // btn_BR
            // 
            this.btn_BR.Location = new System.Drawing.Point(235, 106);
            this.btn_BR.Name = "btn_BR";
            this.btn_BR.Size = new System.Drawing.Size(181, 41);
            this.btn_BR.TabIndex = 5;
            this.btn_BR.Text = "Watch a BluRay or play a game";
            this.btn_BR.UseVisualStyleBackColor = true;
            this.btn_BR.Click += new System.EventHandler(this.btn_BR_Click);
            // 
            // btn_Record
            // 
            this.btn_Record.Location = new System.Drawing.Point(25, 162);
            this.btn_Record.Name = "btn_Record";
            this.btn_Record.Size = new System.Drawing.Size(181, 41);
            this.btn_Record.TabIndex = 6;
            this.btn_Record.Text = "Listen to a Record";
            this.btn_Record.UseVisualStyleBackColor = true;
            this.btn_Record.Click += new System.EventHandler(this.btn_Record_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(59, 399);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Sound System";
            // 
            // btn_CD
            // 
            this.btn_CD.Location = new System.Drawing.Point(235, 162);
            this.btn_CD.Name = "btn_CD";
            this.btn_CD.Size = new System.Drawing.Size(181, 41);
            this.btn_CD.TabIndex = 8;
            this.btn_CD.Text = "Listen to a CD";
            this.btn_CD.UseVisualStyleBackColor = true;
            this.btn_CD.Click += new System.EventHandler(this.btn_CD_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(83, 366);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "CD Deck";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(71, 220);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 20);
            this.label7.TabIndex = 10;
            this.label7.Text = "Device";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(231, 220);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 20);
            this.label8.TabIndex = 11;
            this.label8.Text = "State";
            // 
            // txt_TV
            // 
            this.txt_TV.Location = new System.Drawing.Point(235, 264);
            this.txt_TV.Name = "txt_TV";
            this.txt_TV.Size = new System.Drawing.Size(100, 20);
            this.txt_TV.TabIndex = 12;
            // 
            // txt_BR
            // 
            this.txt_BR.Location = new System.Drawing.Point(235, 294);
            this.txt_BR.Name = "txt_BR";
            this.txt_BR.Size = new System.Drawing.Size(100, 20);
            this.txt_BR.TabIndex = 13;
            // 
            // txt_Record
            // 
            this.txt_Record.Location = new System.Drawing.Point(235, 329);
            this.txt_Record.Name = "txt_Record";
            this.txt_Record.Size = new System.Drawing.Size(100, 20);
            this.txt_Record.TabIndex = 14;
            // 
            // txt_CD
            // 
            this.txt_CD.Location = new System.Drawing.Point(235, 363);
            this.txt_CD.Name = "txt_CD";
            this.txt_CD.Size = new System.Drawing.Size(100, 20);
            this.txt_CD.TabIndex = 15;
            // 
            // txt_Sound
            // 
            this.txt_Sound.Location = new System.Drawing.Point(235, 396);
            this.txt_Sound.Name = "txt_Sound";
            this.txt_Sound.Size = new System.Drawing.Size(100, 20);
            this.txt_Sound.TabIndex = 16;
            // 
            // btn_Off
            // 
            this.btn_Off.Location = new System.Drawing.Point(25, 42);
            this.btn_Off.Name = "btn_Off";
            this.btn_Off.Size = new System.Drawing.Size(391, 47);
            this.btn_Off.TabIndex = 17;
            this.btn_Off.Text = "All Off";
            this.btn_Off.UseVisualStyleBackColor = true;
            this.btn_Off.Click += new System.EventHandler(this.btn_Off_Click);
            // 
            // frmRemote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 471);
            this.Controls.Add(this.btn_Off);
            this.Controls.Add(this.txt_Sound);
            this.Controls.Add(this.txt_CD);
            this.Controls.Add(this.txt_Record);
            this.Controls.Add(this.txt_BR);
            this.Controls.Add(this.txt_TV);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btn_CD);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btn_Record);
            this.Controls.Add(this.btn_BR);
            this.Controls.Add(this.btn_TV);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmRemote";
            this.Text = "Entertainment Center Remote";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_TV;
        private System.Windows.Forms.Button btn_BR;
        private System.Windows.Forms.Button btn_Record;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_CD;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_TV;
        private System.Windows.Forms.TextBox txt_BR;
        private System.Windows.Forms.TextBox txt_Record;
        private System.Windows.Forms.TextBox txt_CD;
        private System.Windows.Forms.TextBox txt_Sound;
        private System.Windows.Forms.Button btn_Off;
    }
}

