﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade_Pattern
{
    public class Record       // A subsystem class to control the Turntable
    {
        private bool isOn = false;

        public bool turnTblOn()     // Determines if turntable is on
        {
            return isOn;
        }

        public void recON()
        {
            isOn = true;
        }

        public void recOFF() 
        {
            isOn = false;
        }
    }
}
