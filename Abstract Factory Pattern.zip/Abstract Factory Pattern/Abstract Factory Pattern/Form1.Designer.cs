﻿namespace Abstract_Factory_Pattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtPasta = new System.Windows.Forms.TextBox();
            this.txtSauce = new System.Windows.Forms.TextBox();
            this.txtMeat = new System.Windows.Forms.TextBox();
            this.txtExtra = new System.Windows.Forms.TextBox();
            this.txtSideP = new System.Windows.Forms.TextBox();
            this.txtSub = new System.Windows.Forms.TextBox();
            this.txtBread = new System.Windows.Forms.TextBox();
            this.txtCheese = new System.Windows.Forms.TextBox();
            this.txtTopp = new System.Windows.Forms.TextBox();
            this.txtSideS = new System.Windows.Forms.TextBox();
            this.txtOrder = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btn_Pasta = new System.Windows.Forms.Button();
            this.btn_Sandwich = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sandwich";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Pasta ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Pasta";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(169, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Sauce";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(334, 48);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Meat";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 98);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Extra";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(306, 92);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(28, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Side";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 170);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Substance";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(190, 173);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Bread";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(358, 173);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Cheese";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 220);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Toppings";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(207, 220);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(28, 13);
            this.label12.TabIndex = 11;
            this.label12.Text = "Side";
            // 
            // txtPasta
            // 
            this.txtPasta.Location = new System.Drawing.Point(52, 48);
            this.txtPasta.Name = "txtPasta";
            this.txtPasta.Size = new System.Drawing.Size(100, 20);
            this.txtPasta.TabIndex = 12;
            // 
            // txtSauce
            // 
            this.txtSauce.Location = new System.Drawing.Point(213, 45);
            this.txtSauce.Name = "txtSauce";
            this.txtSauce.Size = new System.Drawing.Size(100, 20);
            this.txtSauce.TabIndex = 13;
            // 
            // txtMeat
            // 
            this.txtMeat.Location = new System.Drawing.Point(371, 45);
            this.txtMeat.Name = "txtMeat";
            this.txtMeat.Size = new System.Drawing.Size(100, 20);
            this.txtMeat.TabIndex = 14;
            // 
            // txtExtra
            // 
            this.txtExtra.Location = new System.Drawing.Point(52, 95);
            this.txtExtra.Name = "txtExtra";
            this.txtExtra.Size = new System.Drawing.Size(212, 20);
            this.txtExtra.TabIndex = 15;
            // 
            // txtSideP
            // 
            this.txtSideP.Location = new System.Drawing.Point(349, 92);
            this.txtSideP.Name = "txtSideP";
            this.txtSideP.Size = new System.Drawing.Size(100, 20);
            this.txtSideP.TabIndex = 16;
            // 
            // txtSub
            // 
            this.txtSub.Location = new System.Drawing.Point(73, 170);
            this.txtSub.Name = "txtSub";
            this.txtSub.Size = new System.Drawing.Size(100, 20);
            this.txtSub.TabIndex = 17;
            // 
            // txtBread
            // 
            this.txtBread.Location = new System.Drawing.Point(231, 170);
            this.txtBread.Name = "txtBread";
            this.txtBread.Size = new System.Drawing.Size(100, 20);
            this.txtBread.TabIndex = 18;
            // 
            // txtCheese
            // 
            this.txtCheese.Location = new System.Drawing.Point(407, 173);
            this.txtCheese.Name = "txtCheese";
            this.txtCheese.Size = new System.Drawing.Size(100, 20);
            this.txtCheese.TabIndex = 19;
            // 
            // txtTopp
            // 
            this.txtTopp.Location = new System.Drawing.Point(73, 213);
            this.txtTopp.Name = "txtTopp";
            this.txtTopp.Size = new System.Drawing.Size(100, 20);
            this.txtTopp.TabIndex = 20;
            // 
            // txtSideS
            // 
            this.txtSideS.Location = new System.Drawing.Point(241, 213);
            this.txtSideS.Name = "txtSideS";
            this.txtSideS.Size = new System.Drawing.Size(100, 20);
            this.txtSideS.TabIndex = 21;
            // 
            // txtOrder
            // 
            this.txtOrder.Location = new System.Drawing.Point(9, 273);
            this.txtOrder.Multiline = true;
            this.txtOrder.Name = "txtOrder";
            this.txtOrder.Size = new System.Drawing.Size(498, 178);
            this.txtOrder.TabIndex = 22;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(5, 254);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(55, 16);
            this.label13.TabIndex = 23;
            this.label13.Text = "Orders";
            // 
            // btn_Pasta
            // 
            this.btn_Pasta.Location = new System.Drawing.Point(123, 6);
            this.btn_Pasta.Name = "btn_Pasta";
            this.btn_Pasta.Size = new System.Drawing.Size(112, 23);
            this.btn_Pasta.TabIndex = 24;
            this.btn_Pasta.Text = "Order a Pasta";
            this.btn_Pasta.UseVisualStyleBackColor = true;
            this.btn_Pasta.Click += new System.EventHandler(this.btn_Pasta_Click);
            // 
            // btn_Sandwich
            // 
            this.btn_Sandwich.Location = new System.Drawing.Point(123, 130);
            this.btn_Sandwich.Name = "btn_Sandwich";
            this.btn_Sandwich.Size = new System.Drawing.Size(112, 23);
            this.btn_Sandwich.TabIndex = 25;
            this.btn_Sandwich.Text = "Order a Sandwich";
            this.btn_Sandwich.UseVisualStyleBackColor = true;
            this.btn_Sandwich.Click += new System.EventHandler(this.btn_Sandwich_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(522, 464);
            this.Controls.Add(this.btn_Sandwich);
            this.Controls.Add(this.btn_Pasta);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtOrder);
            this.Controls.Add(this.txtSideS);
            this.Controls.Add(this.txtTopp);
            this.Controls.Add(this.txtCheese);
            this.Controls.Add(this.txtBread);
            this.Controls.Add(this.txtSub);
            this.Controls.Add(this.txtSideP);
            this.Controls.Add(this.txtExtra);
            this.Controls.Add(this.txtMeat);
            this.Controls.Add(this.txtSauce);
            this.Controls.Add(this.txtPasta);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtPasta;
        private System.Windows.Forms.TextBox txtSauce;
        private System.Windows.Forms.TextBox txtMeat;
        private System.Windows.Forms.TextBox txtExtra;
        private System.Windows.Forms.TextBox txtSideP;
        private System.Windows.Forms.TextBox txtSub;
        private System.Windows.Forms.TextBox txtBread;
        private System.Windows.Forms.TextBox txtCheese;
        private System.Windows.Forms.TextBox txtTopp;
        private System.Windows.Forms.TextBox txtSideS;
        private System.Windows.Forms.TextBox txtOrder;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btn_Pasta;
        private System.Windows.Forms.Button btn_Sandwich;
    }
}

