﻿namespace Iterator_Pattern
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Iterate = new System.Windows.Forms.Button();
            this.lbx_Collection = new System.Windows.Forms.ListBox();
            this.btn_Reverse = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Iterate
            // 
            this.btn_Iterate.Location = new System.Drawing.Point(23, 30);
            this.btn_Iterate.Name = "btn_Iterate";
            this.btn_Iterate.Size = new System.Drawing.Size(144, 30);
            this.btn_Iterate.TabIndex = 0;
            this.btn_Iterate.Text = "Iterate Swimmers";
            this.btn_Iterate.UseVisualStyleBackColor = true;
            this.btn_Iterate.Click += new System.EventHandler(this.btn_Iterate_Click);
            // 
            // lbx_Collection
            // 
            this.lbx_Collection.FormattingEnabled = true;
            this.lbx_Collection.Location = new System.Drawing.Point(237, 66);
            this.lbx_Collection.Name = "lbx_Collection";
            this.lbx_Collection.Size = new System.Drawing.Size(249, 264);
            this.lbx_Collection.TabIndex = 1;
            // 
            // btn_Reverse
            // 
            this.btn_Reverse.Location = new System.Drawing.Point(23, 219);
            this.btn_Reverse.Name = "btn_Reverse";
            this.btn_Reverse.Size = new System.Drawing.Size(144, 30);
            this.btn_Reverse.TabIndex = 2;
            this.btn_Reverse.Text = "Reverse Iteration";
            this.btn_Reverse.UseVisualStyleBackColor = true;
            this.btn_Reverse.Click += new System.EventHandler(this.btn_Reverse_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(527, 396);
            this.Controls.Add(this.btn_Reverse);
            this.Controls.Add(this.lbx_Collection);
            this.Controls.Add(this.btn_Iterate);
            this.Name = "Form1";
            this.Text = "200m Medley Rio 2016";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Iterate;
        private System.Windows.Forms.ListBox lbx_Collection;
        private System.Windows.Forms.Button btn_Reverse;
    }
}

