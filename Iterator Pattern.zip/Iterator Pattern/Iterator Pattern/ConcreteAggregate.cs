﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator_Pattern
{
    public class ConcreteAggregate : Aggregate // the Concrete Aggregate class
    {
        public ConcreteAggregate()
        {
            Swimmers = new List<string>();
        }

        public override Iterator createIterator()
        {
            return new ConcreteIterator(this);
        }

        public override Iterator createReverseIter()
        {
            return new ReverseConcreteIterator(this);
        }
    }

}