﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Iterator_Pattern
{
    public partial class Form1 : Form
    {
        Aggregate agr = new ConcreteAggregate();
        Iterator iterator;
        Iterator reverse;


        public Form1()
        {
            InitializeComponent();
            PrepareAgrWithIter();
        }

        private void PrepareAgrWithIter()
        {
            agr.Swimmers.Add("Michael Phelps - Gold Medal");
            agr.Swimmers.Add("Kosuke Hagino - Silver Medal");
            agr.Swimmers.Add("Wang Shun - Bronze Medal");
            agr.Swimmers.Add("Hiromasa Fujimori - 4th place");
            agr.Swimmers.Add("Ryan Lochte - 5th place");
            agr.Swimmers.Add("Philip Heintz - 6th place");
            agr.Swimmers.Add("Thiago Pereira - 7th place");
            agr.Swimmers.Add("Daniel Wallace - 8th place");
            iterator = agr.createIterator();
            reverse = agr.createReverseIter();

        }

        private void btn_Iterate_Click(object sender, EventArgs e)
        {
            iterator.First();
            while (!iterator.IsDone())
            {
                lbx_Collection.Items.Add(iterator.currentItem());
                iterator.Next();
            }
        }

        private void btn_Reverse_Click(object sender, EventArgs e)
        {
            reverse.First();
            while (!reverse.IsDone())
            {
                lbx_Collection.Items.Add(reverse.currentItem());
                reverse.Next();
            }
        }
    }
}
