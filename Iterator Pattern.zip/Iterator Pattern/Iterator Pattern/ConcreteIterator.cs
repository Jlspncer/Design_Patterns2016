﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator_Pattern
{
    public class ConcreteIterator : Iterator
    {
        Aggregate aggregate;
        int index;

        public ConcreteIterator(Aggregate agr)
        {
            aggregate = agr;
        }
        
        public override object First()
        {
            index = 0;
            return currentItem();
        }

        public override object Next()
        {
            if (!IsDone())
                index++;
            return currentItem();
        }

        public override bool IsDone()
        {
            return (index > aggregate.Swimmers.Count - 1);
        }

        public override object currentItem()
        {
            if (IsDone())
                return null;
            return aggregate.Swimmers[index];
        }
    }
}
