﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator_Pattern
{
    public class ReverseConcreteIterator : Iterator
    {
         Aggregate reverseAggregate;
        int index;

        public ReverseConcreteIterator(Aggregate agr)
        {
            reverseAggregate = agr;
        }
        
        public override object First()
        {
            index = reverseAggregate.Swimmers.Count - 1; // iterates from the bottom up
            return currentItem();
        }

        public override object Next()
        {
            if (!IsDone())
              index--; // continues in the reverse 
            return currentItem();
        }

        public override bool IsDone()
        {
           return index < 0; // tells the reverse action to stop at the end
        }

        public override object currentItem()
        {
            if (IsDone())
                return null;
            return reverseAggregate.Swimmers[index];
        }
    }
}