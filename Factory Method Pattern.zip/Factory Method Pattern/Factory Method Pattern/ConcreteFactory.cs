﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory_Method_Pattern
{
    class ConcreteFactory : Factory
    {
        public override Product newFile(string filetype, string filename)
        {
            if (filetype == "Text File")
                return new TextFile(filename);
            return null;
        }
    }
}
