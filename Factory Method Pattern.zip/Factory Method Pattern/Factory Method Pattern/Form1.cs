﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Factory_Method_Pattern
{
    public partial class Form1 : Form
    {
        string name;
        ConcreteFactory factory = new ConcreteFactory();
        public Form1()
        {
            InitializeComponent();
        }
        private void btn_Create_Click(object sender, EventArgs e)
        {
            name = txt_Name.Text;
            string text = txt_EnterText.Text;
            factory.generateFile("Text File", name, text);
        }
    }
}
