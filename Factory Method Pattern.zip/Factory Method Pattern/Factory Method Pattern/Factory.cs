﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory_Method_Pattern
{
    public abstract class Factory
    {
        public void generateFile(string filetype, string filename, string text)
        {
            Product file = newFile(filetype, filename);
            file.generateFile();
            file.writeFile(text);
        }

        public abstract Product newFile(string filetype, string filename);
    }
}
