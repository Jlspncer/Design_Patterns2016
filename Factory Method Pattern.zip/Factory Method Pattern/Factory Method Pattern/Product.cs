﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory_Method_Pattern
{
    public interface Product
    {
        string getFileName();
        string getFileType();
        void generateFile();
        void writeFile(string text);
    }
}
