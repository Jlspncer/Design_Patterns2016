﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory_Method_Pattern
{
    class TextFile : Product
    {
        private string name;
        private string fileType = ".txt";
        public TextFile(string name)
        {
            this.name = name;
        }

        public void generateFile()
        {
            System.IO.File.Create("C:\\Temp\\" + name + fileType).Close();
        }

        public void writeFile(string text)
        {
            System.IO.File.WriteAllText("C:\\Temp\\" + name + fileType, text);
        }

        public string getFileType()
        {
            return fileType;
        }

        public string getFileName()
        {
            return name;
        }
    }
}
